import sqlite3
from sqlite3 import Error

import sqlite3
from sqlite3 import Error

database = "securitydb.db"
class Connection:
    def create_connection(self):
        try:
            return sqlite3.connect(database)
        except Error as e:
            print(e)



class data(Connection):
    def create_connection(self):

        conn = None
        try:
            conn = sqlite3.connect(database)
            return conn

        except Error as e:
            print(e)

        return conn

    def create_table(self,conn, create_table_sql):

        try:
            c = conn.cursor()
            c.execute(create_table_sql)
        except Error as e:
            print(e)

    def CreateDatabase(self):
        database = "securitydb.db"

        sql_create_hguseowner = """ CREATE TABLE IF NOT EXISTS houseowners (
                                            id integer PRIMARY KEY,
                                            name text NOT NULL,
                                            address text NOT NULL,
                                            email text NOT NULL,
                                            phone text NOT NULL,
                                            housenumber int NOT NULL
                                        ); """

        sql_create_visitor = """CREATE TABLE IF NOT EXISTS visitor (
                                        visitorid integer PRIMARY KEY,
                                        name text NOT NULL,
                                        housenumber int NOT NULL,
                                        phone text ,
                                        email text ,
                                        dateofvisit text NOT NULL,
                                        FOREIGN KEY (housenumber) REFERENCES houseowners (housenumber)
                                    );"""

        sql_create_visitorcheckstatus = """CREATE TABLE IF NOT EXISTS visitorcheckstatus (
                                            visitorid int,
                                            name text NOT NULL,
                                            housenumber int NOT NULL,
                                            date text NOT NULL,
                                            time text NOT NULL ,
                                            status text,
                                            FOREIGN KEY (housenumber) REFERENCES visitor (housenumber)
                                        );"""

        # create a database connection
        conn = self.create_connection()

        # create tables
        if conn is not None:

            # create house owner table
            self.create_table(conn, sql_create_hguseowner)

            # create visitor table

            self.create_table(conn, sql_create_visitor)

            # create visitorchecks table
            self.create_table(conn, sql_create_visitorcheckstatus)
        else:
            print("Error! cannot create the database connection.")





