
import sqlite3
from sqlite3 import Error
import colors as cl
db_file = "securitydb.db"
class Client:
    def register(self):
        pass
    def deleteowner(self):
        pass
    def updatedetails(self):
        pass

class HouseOwner(Client):
    id =None
    name = ''
    address = ''
    email = ''
    phone = ''
    housenumber = None

    def register(self,conn):
        """
        register owner
        """
        id = int(input("Enter Owner ID   "))
        name = input("Enter Owner  Name    ")
        address = input("Enter address    ")
        email = input("Enter email    ")
        phone = input("Enter phone    ")
        housenumber = int(input("Enter House Number    "))
        try:
            task = (id,name,address,email,phone,housenumber)
            sql = '''INSERT INTO houseowners(id,name,address,email,phone,housenumber)
                              VALUES(?,?,?,?,?,?) '''
            cur = conn.cursor()
            cur.execute(sql, task)
            conn.commit()
            return cur.lastrowid
        except:
            print("Could not register user")

    def deleteowner(self, conn):
        """
        remove owner
        """

        housenumber = int(input("Enter Owner ID    "))
        try:
            sql = 'DELETE FROM houseowners WHERE id=?'
            cur = conn.cursor()
            cur.execute(sql, (id,))
            conn.commit()
            print("Deleted")

            return cur.lastrowid
        except:
            print("Could not delete user")




    def select_all_owners(self,conn):
        """
       select owners:
        """
        cur = conn.cursor()
        cur.execute("SELECT * FROM houseowners")


        rows = cur.fetchall()
        print('{0}    {1}           {2}            {3}                {4}              {5} '.format('Owner id','name','address','email','phone','housenumber'))


        for row in rows:
            ownerid=str(row[0])
            name = str(row[1])
            address = str(row[2])
            email = str(row[3])
            phone = str(row[4])
            housenumber = str(row[5])

            print('{0}        {1}      {2}       {3}       {4}       {5} '.format(ownerid,name,address, email,phone, housenumber))



    def select_task_by_id(self,conn):
        """
        Query tasks by priority
        :param conn: the Connection object
        :param priority:
        :return:
        """
        cur = conn.cursor()
        id=int(input("Enter House Number    "))
        cur.execute("SELECT * FROM houseowners WHERE housenumber=?", (id,))

        rows = cur.fetchall()
        print('')


        for row in rows:
            print("Owner ID: ", row[0])
            print("Name: ", row[1])
            print("Address: ", row[2])
            print("Email: ", row[3])
            print("Phone: ", row[4])
            print("House Number: ", row[4])









