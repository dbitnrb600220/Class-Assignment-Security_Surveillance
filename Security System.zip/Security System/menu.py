import data as dto
import houseowners as ho
import visitors as vt
import colors as cl
import sys
cls=cl.Colors()

dt=dto.data()
hox = ho.HouseOwner()
vis = vt.Visitor()
class Menu:


    def menu(self):
        ans = True

        while ans:
            print(cls.BLUE)
            print('SELECT MENU OPTION')
            print('-------------------')
            print("""
            1.Register Owner
            2.Search House
            3.View House Owners
            4.Register Visitor
            5.View visitors
            6.Check In  Visitor
            7.Check Out  Visitor
            8.View Check-ins by house number
            9.View Check-ins by date
            10.Delete owner
            0.Exit/Quit
            """)
            print(cls.RED)
            ans = input("What would you like to do?   ")
            print(cls.BLACK)
            print("-----------------------------------------------------------------------------------------")
            print(cls.GREEN)
            if ans == "1":
                hox.register(dt.create_connection())
            elif ans == "2":
                hox.select_task_by_id(dt.create_connection())
            elif ans == "3":
                hox.select_all_owners(dt.create_connection())
            elif ans == "4":
                vis.registerVisitor(dt.create_connection())
            elif ans == "5":
                vis.select_all_visitors(dt.create_connection())
            elif ans == "6":
                vis.select_visitor_by_id(dt.create_connection(), 'cin')
            elif ans == "7":
                vis.select_visitor_by_id(dt.create_connection(), 'cout')
            elif ans == "8":
                vis.searchvisiybyhousenumber(dt.create_connection())
            elif ans == "9":
                vis.searchvisiybyhdate(dt.create_connection())
            elif ans == "10":
                hox.deleteowner(dt.create_connection())
            elif ans == "0":
                print("\n System Exited....")
                ans = None
                sys.exit(0)
            else:
                print("\n Not Valid Choice Try again")
            print(cls.BLACK)
            print("-----------------------------------------------------------------------------------------")

class Main(Menu):
    pass


if __name__ == '__main__':
    mn=Main()
    mn.menu()









