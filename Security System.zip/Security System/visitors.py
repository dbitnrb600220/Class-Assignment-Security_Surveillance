import sqlite3
from sqlite3 import Error
import colors as cl
from datetime import datetime
from datetime import date

db_file = "securitydb.db"
today = date.today()
d1 = today.strftime("%d/%m/%Y")
now = datetime.now()
t1 = now.strftime("%H:%M:%S")


class Visitor:
    visitorid = None
    name = ''
    housenumber = None
    phone = ''
    email = ''
    dateofvisit = ''

    def registerVisitor(self, conn):
        """
        Register a visitor
        """
        id = int(input("Enter Visitor ID   "))
        name = input("Enter Visitor  Name    ")

        email = input("Enter email    ")
        phone = input("Enter phone    ")
        housenumber = int(input("Enter House Number you want to visit   "))

        try:
            task = (id, name, housenumber, phone, email, d1)
            sql = '''INSERT INTO visitor(visitorid,name,housenumber,phone,email,dateofvisit)
                              VALUES(?,?,?,?,?,?) '''
            cur = conn.cursor()
            cur.execute(sql, task)
            conn.commit()

            print('Visitor Registered')
            return cur.lastrowid
        except:
            print("Could not register visitor")

    def select_all_visitors(self, conn):
        """
       select all the visitors
              """
        cur = conn.cursor()
        cur.execute("SELECT * FROM visitor")

        rows = cur.fetchall()
        print('{0}      {1}      {2}      {3}      {4}      {5} '.format('Visitor ID', 'Name', 'House Number', 'Phone',
                                                                         'Email', 'Date of Visit'))

        for row in rows:
            visitorid = str(row[0])
            name = str(row[1])
            housenumber = str(row[2])
            phone = str(row[3])
            email = str(row[4])
            dateofvisit = str(row[5])

            print('{0}      {1}      {2}           {3}      {4}      {5} '.format(visitorid, name, housenumber, phone,
                                                                                  email, dateofvisit))

    def searchvisiybyhousenumber(self, conn):
        """
        search visits

        """
        cur = conn.cursor()
        id = int(input("Enter House Number     "))
        cur.execute("SELECT * FROM visitorcheckstatus WHERE housenumber=?", (id,))

        rows = cur.fetchall()
        print(
            '{0}    {1}           {2}            {3}                {4}              {5} '.format('Visitor id', 'Name',
                                                                                                  'House Number',
                                                                                                  'Date', 'Time',
                                                                                                  'Status'))

        for row in rows:
            visitorid = str(row[0])
            name = str(row[1])
            housenumber = str(row[2])
            date = str(row[3])
            time = str(row[4])
            status = str(row[5])

            print('{0}        {1}      {2}       {3}       {4}       {5} '.format(visitorid, name, housenumber, date,
                                                                                  time, status))

    def searchvisiybyhdate(self, conn):
        """
        search visits

        """
        cur = conn.cursor()
        id = input("Enter Date ( dd/mm/yyyy ) ")
        cur.execute("SELECT * FROM visitorcheckstatus WHERE date=?", (id,))

        rows = cur.fetchall()
        print(
            '{0}    {1}           {2}            {3}                {4}              {5} '.format('Visitor id', 'Name',
                                                                                                  'House Number',
                                                                                                  'Date', 'Time',
                                                                                                  'Status'))

        for row in rows:
            visitorid = str(row[0])
            name = str(row[1])
            housenumber = str(row[2])
            date = str(row[3])
            time = str(row[4])
            status = str(row[5])

            print('{0}        {1}      {2}       {3}       {4}       {5} '.format(visitorid, name, housenumber, date,
                                                                                  time, status))

    def select_visitor_by_id(self, conn, st):
        """
        select visitor by id

        """

        cur = conn.cursor()
        id = int(input("Enter Visitor ID    "))
        cur.execute("SELECT * FROM visitor WHERE visitorid=?", (id,))

        rows = cur.fetchall()
        print('')

        for row in rows:
            name = row[1]
            housenumber = row[2]
            visid = row[0]
            date = d1
            time = t1
            status = ''
            if st == "cin":
                status = 'Checked In'
            else:
                status = 'Checked Out'

            print("Visitor ID: ", row[0])
            print("Name: ", row[1])
            print("House Number: ", row[2])
            print("Phone: ", row[3])
            print("Email: ", row[4])
            print("Date of Visit: ", row[4])

            strWord = input("Enter y to Check     ")
            if strWord == "y":
                try:
                    task = (visid, name, housenumber, date, time, status)
                    sql = '''INSERT INTO visitorcheckstatus(visitorid,name,housenumber,date,time,status)
                                              VALUES(?,?,?,?,?,?) '''
                    cur = conn.cursor()
                    cur.execute(sql, task)
                    conn.commit()
                    print('Visitor ' + status)
                    return cur.lastrowid


                except:
                    print("Visitor could not " + status)
